public class Main {
    public static void main(String[] args) {
ConcreteFactory factory = new ConcreteFactory();
PowerController powerController = factory.createPowerController();
GameController gameController = factory.createGameController();
powerController.turnOn();
gameController.loadGame("Loading...");
gameController.playGame();
gameController.stopGame();
powerController.turnOff();
    }
}