public class PowerController {
        public void turnOn() {
            System.out.println(" PlayStation is turning on");
        }
        public void turnOff() {
            System.out.println(" PlayStation is turning off");
        }
    }

