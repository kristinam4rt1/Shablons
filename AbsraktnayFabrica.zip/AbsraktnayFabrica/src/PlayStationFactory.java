public interface PlayStationFactory {
        PowerController createPowerController();
        GameController createGameController();
    }

