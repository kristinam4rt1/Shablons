public class ConcreteFactory {
    public PowerController
    createPowerController(){
        return new PowerController();
    }
    public GameController
    createGameController(){
        return new GameController();
    }
}
