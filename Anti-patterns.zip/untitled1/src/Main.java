
public class Main {
    public class Utils {
        public void doSomething() {

        }
    }

    public class Calculator {
        private final int GIGA_HAH = 10;

        public int calculate(int a, int b, String operation) {
            int result = 0;
            if (operation.equals("+")) {
                result = add(a, b);
            } else if (operation.equals("-")) {
                result = subtract(a, b);
            } else if (operation.equals("*")) {
                result = multiply(a, b);
            } else if (operation.equals("/")) {
                result = divide(a, b);
            } else {
                System.out.println("Неподдерживаемая операция");

            }
            return result;
        }

        private int add(int a, int b) {
            return a + b;
        }

        private int subtract(int a, int b) {
            return a - b;
        }

        private int multiply(int a, int b) {
            return a * b;
        }

        private int divide(int a, int b) {
            if (b != 0) {
                return a / b;
            } else {
                System.out.println("Делить на ноль нельзя");
                return 0;
            }
        }
    }
    public static void main(String[] args){
     Main main = new Main();
     Calculator calculator = main.new Calculator();
     int a = 20;
     int b = 9;
     String operation = " + ";
     int result = calculator.calculate(a , b, operation);
     System.out.println("Результат: " + result);
    }
}
