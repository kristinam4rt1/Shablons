
    class PowerHandler implements Handler {
        private Handler nextHandler;

        @Override
        public void setNextHandler(Handler handler) {
            this.nextHandler = handler;
        }

        @Override
        public void handleRequest(String request) {
            if (request.equalsIgnoreCase("power on")) {
                System.out.println("PlayStation is turning on");
            } else if (request.equalsIgnoreCase("power off")) {
                System.out.println("PlayStation is turning off");
            } else if (nextHandler != null) {
                nextHandler.handleRequest(request);
            } else {
                System.out.println("Unable to handle request");
            }
        }
    }

