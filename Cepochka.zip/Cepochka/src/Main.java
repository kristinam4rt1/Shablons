// Клиентский код
public class Main {
    public static void main(String[] args) {
        Handler powerHandler = new PowerHandler();
        Handler gameHandler = new GameHandler();

        powerHandler.setNextHandler(gameHandler);

        powerHandler.handleRequest("power on");
        powerHandler.handleRequest("play God of War");
        powerHandler.handleRequest("power off");
        powerHandler.handleRequest("pause");
    }
}