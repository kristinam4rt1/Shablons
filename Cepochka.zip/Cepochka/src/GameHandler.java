class GameHandler implements Handler {
    private Handler nextHandler;

    @Override
    public void setNextHandler(Handler handler) {
        this.nextHandler = handler;
    }

    @Override
    public void handleRequest(String request) {
        if (request.toLowerCase().startsWith("play")) {
            String gameName = request.substring(5);
            System.out.println("Loading and playing game: " + gameName);
        } else if (nextHandler != null) {
            nextHandler.handleRequest(request);
        } else {
            System.out.println("Unable to handle request");
        }
    }
}