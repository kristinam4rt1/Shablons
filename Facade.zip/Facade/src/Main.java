public class Main {
    public static void main (String[] args){
        PlayStationFacade playStation = new PlayStationFacade();
        playStation.startGame("The Last of Us");
        playStation.stopGame();
    }
}
