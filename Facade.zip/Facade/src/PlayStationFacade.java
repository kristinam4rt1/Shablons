public class PlayStationFacade {

        private PowerController powerController;
        private GameController gameController;
        public PlayStationFacade(){
            this.powerController = new PowerController();
            this.gameController = new GameController();
        }
        public void startGame(String game){
            powerController.turnOn();
            gameController.loadGame(game);
            gameController.playGame(game);
        }
        public void stopGame(){
            gameController.stopGame();
            powerController.turnOff();
        }
    }


