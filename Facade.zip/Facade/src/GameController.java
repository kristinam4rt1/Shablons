public class GameController {
    public void loadGame(String game) {
        System.out.println("loading  game: " + game);
    }
    public void playGame(String game) {
        System.out.println("playing game");
    }
    public void stopGame() {
        System.out.println("stopping game");
    }
}